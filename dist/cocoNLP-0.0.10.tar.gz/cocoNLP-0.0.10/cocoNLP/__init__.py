# -*- coding: utf-8 -*-
#                      _   _ _     ____
#   ___ ___   ___ ___ | \ | | |   |  _ \
#  / __/ _ \ / __/ _ \|  \| | |   | |_) |
# | (_| (_) | (_| (_) | |\  | |___|  __/
#  \___\___/ \___\___/|_| \_|_____|_|


# -*- coding: utf-8 -*-

"""
cocoNLP module
:copyright: (c) 2018 by Yang Yang.
:license: MIT, see LICENSE for more details.
"""
