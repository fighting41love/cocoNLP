# -*- coding: utf-8 -*-
#                      _   _ _     ____
#   ___ ___   ___ ___ | \ | | |   |  _ \
#  / __/ _ \ / __/ _ \|  \| | |   | |_) |
# | (_| (_) | (_| (_) | |\  | |___|  __/
#  \___\___/ \___\___/|_| \_|_____|_|



__title__ = "cocoNLP"
__description__ = "Python implementation of many nlp algorithms"
__url__ = "https://github.com/fighting41love"
__version__ = "0.0.11"
__author__ = "Yang Yang"
__author_email__ = "yangyangfuture@gmail.com"
__license__ = "MIT"
__copyright__ = "Copyright 2018 Yang Yang"
